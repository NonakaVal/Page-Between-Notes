---
area: "[[Desenvolvimento Pessoal]]"
tags: area/desenvolvimento_pessoal
type: area_family
created: "[[2025-10-15]]"
---

 `BUTTON[TEMPLATE-CRIAR-NOVA-AREA]`     

```meta-bind-button
label: Criar Nota da Area
icon: plus
hidden: true
class: ""
id: TEMPLATE-CRIAR-NOVA-AREA
style: primary
actions:
  - type: command
    command: quickadd:choice:6430f0b6-4d07-44f9-9b1a-45e79f6bee19
```




