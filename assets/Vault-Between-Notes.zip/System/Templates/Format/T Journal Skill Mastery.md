---
created: '[[<% tp.date.now("YYYY-MM-DD") %>]]'
tags:
  - Journal
Skill: 
Initial Goals: 
Current Level: 
Resources: 
Date Started:
---

# DATA
**Sessão de Prática:**
- Duração:
- Áreas de Foco:

**Desafios e Soluções:**
- 

**Descobertas e Principais Aprendizados:**
- 

**Próximos Passos:**
- 
