---
created: '[[<% tp.date.now("YYYY-MM-DD") %>]]'
tags:
  - memo
  - garden/seed
---
