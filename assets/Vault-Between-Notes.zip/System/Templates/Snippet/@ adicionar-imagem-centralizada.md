<center>
  <img src="<% tp.system.prompt("img link")%>" width="<% tp.system.prompt("width")%>">
</center>
