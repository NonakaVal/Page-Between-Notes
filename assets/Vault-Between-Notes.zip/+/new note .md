---
tags:
  - garden/seed
created: "[[2025-10-31]]"
up: "[[@-Mapas]]"
collection:
---
qualquer coisa kk


Last modified :   `="[[" + dateformat(date(today), "yyyy-MM-dd") + "]]"` - `$= dv.current().file.mtime`

