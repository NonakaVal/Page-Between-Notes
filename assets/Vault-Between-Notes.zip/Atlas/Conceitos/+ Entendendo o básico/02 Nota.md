---
up: "[[++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
Pelo botão :  `BUTTON[new-note]`      ou pelo atalho `ctrl + N` , Toda nota é criada inicialmente da pasta `+`. 

<br>

 Seguir para ➡️ [[03 Propriedades]]




```meta-bind-button
label: Nova Nota
hidden: true
icon: plus
class: ""
id: new-note
style: primary
actions:
  - type: command
    command: quickadd:choice:3edf5ca1-598e-42e8-beec-fe2714a9a1f9
```

