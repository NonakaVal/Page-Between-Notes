List of media resources and acknowledgement of media resources used in this tool.

![[computer-820281.jpg]]
Image by <a href="https://pixabay.com/users/fancycrave1-1115284/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=820281">fancycrave1</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=820281">Pixabay</a>

![[coffee-1869820_1920.jpeg]]
Image by <a href="https://pixabay.com/users/pexels-2286921/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=1869820">Pexels</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=1869820">Pixabay</a>

![[hands-1373363_1920.jpg]]
Image by <a href="https://pixabay.com/users/terimakasih0-624267/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=1373363">Dean Moriarty</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=1373363">Pixabay</a>

![[office-820390_1920.jpg]]
Image by <a href="https://pixabay.com/users/fancycrave1-1115284/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=820390">fancycrave1</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=820390">Pixabay</a>


![[apple-1282241_1920.jpg]]
Image by <a href="https://pixabay.com/users/pexels-2286921/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=1282241">Pexels</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=1282241">Pixabay</a>



![[writing-2317766_1920.jpg]]
Image by <a href="https://pixabay.com/users/charutyagi-5337093/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=2317766">CharuTyagi</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=2317766">Pixabay</a>


![[notebook-1840276_1920.jpg]]
Image by <a href="https://pixabay.com/users/pexels-2286921/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=1840276">Pexels</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=1840276">Pixabay</a>


![[bullet-2428875_1920.jpg]]
Image by <a href="https://pixabay.com/users/rayedigitaldesigns-5446944/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=2428875">Amanda Randolph</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=2428875">Pixabay</a>

![[student-865073_1920.jpg]]
Image by <a href="https://pixabay.com/users/picjumbo_com-2130229/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=865073">free stock photos from www.picjumbo.com</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=865073">Pixabay</a>

![[sunrise-8290940_1920.jpg]]
Image by <a href="https://pixabay.com/users/tama66-1032521/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=8290940">Peter H</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=8290940">Pixabay</a>


![[sunset-8331285_1920.jpg]]
Image by <a href="https://pixabay.com/users/gonzavespa150-9804315/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=8331285">Gonzalo de Martorell</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=8331285">Pixabay</a>

![[artistic-1238606_1920.jpg]]
Image by <a href="https://pixabay.com/users/shutterbug75-2077322/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=1238606">Robert Owen-Wahl</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=1238606">Pixabay</a>

![[smile-5128742_1920.jpg]]
Image by <a href="https://pixabay.com/users/kranich17-11197573/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=5128742">Michaela, at home in Germany • Thank you very much for a like</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=5128742">Pixabay</a>

![[painting-911804_1920.jpg]]
Image by <a href="https://pixabay.com/users/bodobe-1222375/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=911804">Bodo Bertuleit</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=911804">Pixabay</a>

![[sad-4209944_1920.jpg]]
Image by <a href="https://pixabay.com/users/johnnaturephotos-11966122/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=4209944">John</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=4209944">Pixabay</a>

![[eyeglasses-8227429_1920.jpg]]
Image by <a href="https://pixabay.com/users/beasternchen-32364022/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=8227429">beasternchen</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=8227429">Pixabay</a>

![[bookshelf-413705_1920.jpg]]
Image by <a href="https://pixabay.com/users/jaymantri-362084/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=413705">JayMantri</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=413705">Pixabay</a>

![[piano-7629023_1920.jpg]]
Image by <a href="https://pixabay.com/users/oovstudio-7350213/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=7629023">Reuven Hayoon</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=7629023">Pixabay</a>

![[anxiety-2019928_1920.jpg]]
Image by <a href="https://pixabay.com/users/wokandapix-614097/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=2019928">WOKANDAPIX</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=2019928">Pixabay</a>


![[navigation-7320887_1920.jpg]]
Image by <a href="https://pixabay.com/users/orko46-16495679/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=7320887">Marco Rückauer</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=7320887">Pixabay</a>


![[library-2811601_1920.jpg]]
Image by <a href="https://pixabay.com/users/homestead1997-975467/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=2811601">homestead1997</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=2811601">Pixabay</a>

![[../other/contact-us-1426589_640.png|200]]
Image by <a href="https://pixabay.com/users/maklay62-182851/?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=1426589">S K</a> from <a href="https://pixabay.com//?utm_source=link-attribution&utm_medium=referral&utm_campaign=image&utm_content=1426589">Pixabay</a>