---
created: ["{{date}} {{time}}"]
tags:
- Log/DaiLyLog
---

# 📅 Registros {{date: DD-MM-YYYY}}

---
## 🔷 Tarefas do Dia
- [ ] Café da manhã  
- [ ] Estudar algo  
- [ ] Trabalhar em projetos pessoais  
- [ ] Treinar  
	- [ ] Flexões  
	- [ ] Abdominais  
	- [ ] Mergulhos (ou “dips”)  

# 🕴 Negócios
## 🎯 Objetivos
- 

## 🚀 Trabalhando em
- 

## 📕 Lembretes
- 

## 📚 Leitura
- 

## 💬 Sentimentos Persistentes, Observações e Pensamentos
1. Sentimentos Persistentes  
	1. 
2. Observações  
	1. 
3. Pensamentos  
	1. 

## 🔃 Reflexão
1. 

---

## 📅 Anotações do Dia
- 🕛9:00  
	- Acordei e...
