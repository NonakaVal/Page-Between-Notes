
```dataview
TABLE <% tp.system.prompt("TABLE")%>
FROM "<% tp.system.prompt("FROM")%>"
WHERE type = "<% tp.system.prompt("WHERE")%>"
```