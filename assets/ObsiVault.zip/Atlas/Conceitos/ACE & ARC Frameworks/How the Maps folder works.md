---
up: "[[++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
Mapas de conteúdo "mapeiam" partes relevantes de informação no contexto de outras "coisas". Praticamente, isso significa que MOCs podem ajudar você a ***reunir, desenvolver e navegar ideias***. À medida que você cria e personaliza o mapa, você está dando sentido a alguma parte do mundo que importa para você.  
