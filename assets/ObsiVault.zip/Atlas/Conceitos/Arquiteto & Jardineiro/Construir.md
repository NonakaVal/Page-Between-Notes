---
up: "[[++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
~ [[Arquiteto]] 

> [!scale] [[Construir]] | [[Renovar]] — [[Jardineiro]] ⤵️

Quando você tem um **mapa de conteúdo novo ou inacabado** que ainda precisa de atenção, atribua a tag `#architect/build`.  

