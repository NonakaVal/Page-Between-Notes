---
up: "[[++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
> [!trees] [[Plante]] | **[[Cultive]]** | [[Questione]] | [[Replantar]] | [[Revitalizar]] | [[Revisitar]] — [[Arquiteto]] ⤴️  

Quando você estiver em uma nota e sentir que quer voltar a ela, basta adicionar a tag `garden` nessa nota.  
Não importa se você tem um motivo claro ou apenas uma sensação vaga.  
Depois, por meio das seguintes visualizações do Garden, você poderá encontrá-la novamente (e criar conexões serendipitosas pelo caminho).  
