---
up: "[[++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
~ [[Jardineiro]]

> [!trees] [[Plante]] | **[[Cultive]]** | [[Questione]] | [[Replantar]] | [[Revitalizar]] | [[Revisitar]] — [[Arquiteto]] ⤴️  

Se você marcou notas com `#garden/repot`, então você quer **refatorar essas notas dividindo ou reformatando-as.** Isso geralmente envolve cortar uma seção específica de uma nota diária e colar o conteúdo em uma nova nota com um título claro.
