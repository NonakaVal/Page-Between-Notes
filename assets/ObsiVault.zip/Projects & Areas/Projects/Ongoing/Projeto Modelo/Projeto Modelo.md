---
project: "[[Projeto modelo]]"
tags: project/projeto_modelo
type: project
created: "[[2025-10-21]]"
inicio: 2025-10-21
entrega: 2025-10-31
status: to start
---

| Data Início                                              | Data Entrega                                              | Status                                                                                                         |
| -------------------------------------------------------- | --------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------- |
| `INPUT[datePicker(showcase, defaultValue(null)):inicio]` | `INPUT[datePicker(showcase, defaultValue(null)):entrega]` | `INPUT[inlineSelect(option('In Progress'), option('Finished'), option('waiting'), option('to start')):status]` |
```meta-bind-button
label: Criar Nota de Projeto
icon: plus
hidden: false
class: ""
id: TEMPLATE-CRIAR-NOVA-NOTA-PROJETO
style: default
actions:
  - type: command
    command: quickadd:choice:e7c0cfff-583f-4da9-a201-79b4d5a12de4
```

## 🧾 Descrição do Projeto
- 

---
## 📢 Informações do Projeto
Criado em::  21-10-2025 23:39  
Prazo Final::  
Em Hibernação::  
Data de Conclusão Prevista::  
Concluído em::  
Tipo::  
Etiquetas::  
Plataforma::  

___
## 🎯 Objetivo

1. 🟢 Resultado ideal do projeto  
	1. 
2. 🟠 Resultado aceitável  
	1. 

## ❓ Expectativas
1. 🟢 O que pode ajudar o projeto  
	1. 
2. 🟠 Obstáculos potenciais  
	1. 
3. 👶 Inexperiências / Suposições  
	1. 
4. 👨‍💻 Insights e aprendizados  
	1. 

## ✅ Tarefas  
- 

## 📦 Recursos  
- 

## 📂 Registros do Projeto  
- 

